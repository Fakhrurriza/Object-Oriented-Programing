package entity;

/**
 *
 * @author riza
 */
public class buku {
    private String id;
    private String nama;
    private String tahun_terbit;
  
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getNama() {
        return nama;
    }
    
    public void setNama(String nama) {
        this.nama = nama;
    }
    
    public String setTahun_terbit() {
        return tahun_terbit;
    }
    
    public void setTahun_terbit(String tahun_terbit) {
        this.tahun_terbit = tahun_terbit;
    }
    
    public buku(String id, String nama, String tahun_terbit) {
        this.id = id;
        this.nama = nama;
        this.tahun_terbit = tahun_terbit;
    }
    
    public boolean equals(Object object) {
        buku temp = (buku) object;
        return id.equals(temp.getId());
    }
}
