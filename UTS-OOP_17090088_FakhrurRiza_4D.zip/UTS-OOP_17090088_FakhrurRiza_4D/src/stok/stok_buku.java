package stok;

import java.util.*;
import entity.*;
/**
 *
 * @author riza
 */
public class stok_buku {
    
    private static final List<buku> data = new LinkedList<buku>();
    
    public void addData(buku lp) {
        data.add(lp);
        System.out.println("Selamat Data Telah diSimpan");
    }
    
    public void updateData(buku lp){
        int index = data.indexOf(lp);
        if (index >= 0 ) {
        
        data.set(index, lp);
        System.out.println("Selamat Data Telah diUbah");
        }
    }
    
    public void deleteData(String id){
        int idx = data.indexOf(new buku(id, "", ""));
        if(idx >=0) {
            data.remove(idx);
            System.out.println("Selamat Data Telah diHapus");
        }
    }
    
    public void showAllData() {
        int i=1;
        System.out.println("\nData Dalam Daftar");
        for(buku lp : data) {
            System.out.println("data ke-"+ i++);
            System.out.println("ID Buku: " + lp.getId());
            System.out.println("Nama Buku: " + lp.getNama());
            System.out.println("Tahun Terbit : " + lp.setTahun_terbit());
        }
    }
}
